# 学习内容
- 动态创建元素
- Ajax

# 笔记
- TagName返回数组


- Id与TagName混合使用
  
  `var shopping = document.getElementById("purchase")`
 
  `var items = shopping.getElementByTagName("*")`
- ClassName返回数组（包含类名即可）

  与类名顺序无关
-  getAttribute不属于document对象，因此不能使用`document.getAttribute()`
   
   只适用于元素节点
- setAttribute适用于元素节点

  setAttribute做出修改将不会改变源代码
- 调用事件处理函数，添加`return: false;`阻止默认行为的执行
- 可在外部函数中实现点击事件onclick

```
<a class="hhh">`
var links = document.getElementsByTagName("a");
links.onclick = function(){};
```
- 实用函数
```
function addLoadEvent(func){
    var oldonload = window.onload;
    if(typeof window.onload != 'function'){
         window.onload = func;
    }else {
        window.onload = function(){
          oldonload();
          func();
        }
    }
}
addLoadEvent(functionName);
```
/* 思路：将新元素插入到目标元素和目标元素的下一个兄弟元素之间 */
```
function insertAfter(newElement,targetElent){
    var parent = targetElement.parentNode;
    if(parent.lastChild == targetElement){
        parent.appendChild(newElement);
    }else {
        parent.insertBefore(newElement,targetElement.nextSibling);
    }
}