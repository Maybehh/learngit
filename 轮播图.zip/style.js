var timer = null,
    index = 0,
    pics = document.getElementsByClassName("banner-slide"),
    spans = document.getElementsByTagName("span"),
    prev = document.getElementById("preview"),
    next = document.getElementById("next");
//设置第一张照片可见
for(var i=0; i<pics.length; i++){
    if(i == 0){
        pics[i].style.opacity = "1";
    }
    else{pics[i].style.opacity = "0";}
}
//自动轮播
function slideImg(){
    var container = document.getElementById("container");
    //鼠标移开开始轮播
    container.onmouseout = function(){
        startAutoPlay();
    }
    //鼠标移上停止轮播
    container.onmouseover = function(){
        stopAutoPlay();
    }
    container.onmouseout();
    //点击圆点切换图片
    for(var i=0; i<pics.length; i++){
       spans[i].id = i;
       spans[i].onclick = function(){
            index = this.id;
            changeImg();
       }
    }
}

function startAutoPlay(){
    timer = setInterval(function(){
        index++;
        if(index>5){
             index = 0;
        }
        changeImg();
    },2500);
}

function stopAutoPlay(){
    if(timer){
        clearInterval(timer);
    }
}

function changeImg(){
    for(var i=0; i<pics.length; i++){
        pics[i].style.opacity = "0";
        spans[i].className = "";
    }
    pics[index].style.opacity = "1";
    spans[index].className = "changeColor";
}
slideImg();
//点击箭头切换图片
//返回上一张
prev.onclick = turnPrev;
function turnPrev(){
     if(index == 0){
         index = pics.length - 1;
     }
     else{
         index = --index % pics.length;
     }
    for(var i=0; i<pics.length; i++){
        pics[i].style.opacity = "0";
        spans[i].className = "";
    }
    pics[index].style.opacity = "1";
    spans[index].className = "changeColor";
}
//切换下一张
next.onclick = turnNext;
function turnNext(){
     if(index == pics.length - 1){
         index = 0;
     }
     else{
         index = ++index % pics.length;
     }
     for(var i=0; i<pics.length; i++){
        pics[i].style.opacity = "0";
        spans[i].className = "";
    }
    pics[index].style.opacity = "1";
    spans[index].className = "changeColor";
}
