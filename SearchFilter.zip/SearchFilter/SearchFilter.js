var personArr = [
    {name: "王港", src: "1.img", des: "颈椎不好", sex: "m"}, 
    {name: "刘莹", src: "1.img", des: "我是谁", sex: "f"}, 
    {name: "王秀英", src: "1.img", des: "我很好看", sex: "f"}, 
    {name: "刘金磊", src: "1.img", des: "你没见过陌生的脸", sex: "m"}, 
    {name: "柳飞", src: "1.img", des: "瓜皮刘", sex: "m"}
];

var state = {
    text: '',   //定义全局保证两个筛选函数都可使用
    sex: 'a'     //定义全局保证两个筛选函数都可使用，一开始是默认选中All
}

var oUl = document.getElementsByTagName('ul')[0];
var oSearch = document.getElementsByClassName('search-box')[0];
var oP = document.getElementsByTagName('p')[0];
var lastFilterFunc = unionFilterFunc({text: filterText, sex: filterSex});

function renderList(arr) {
    var str = '';
    arr.forEach(function (ele, index) {   // \实现字符串可分行
        str +=  '<li>\
                    <img src=' + ele.src + '/>\
                    <p class="username">' + ele.name + '</p>\
                    <p class="des">' + ele.des + '</p>\
                </li>';
    });
    oUl.innerHTML = str;
}

oSearch.oninput = function () {
    state.text = this.value;
    renderList(lastFilterFunc(personArr));
}

function filterText(text, arr) {
    return arr.filter(function (ele, index) {
        return ele.name.indexOf(text) != -1;
    });
}

oP.addEventListener('click', function (e) {  //事件冒泡，点击span冒泡到p上执行该函数
    if(e.target.nodeName == 'SPAN') {   //点到缝隙就是p标签而不是span标签
        document.getElementsByClassName('active')[0].className = "";
        e.target.className = "active";
        state.sex = e.target.getAttribute('sex');
        renderList(lastFilterFunc(personArr));
    }
});

function filterSex(sex, arr) {
    if(sex == 'a') {
        return arr;
    } else {
        return arr.filter(function (ele, index) {
            return ele.sex == sex;
        });
    }
}

function unionFilterFunc(obj) {   //合并筛选函数
    return function (arr) {
        var lastArr = arr;
        for(var prop in obj) {
            lastArr = obj[prop](state[prop], lastArr);
        }
        return lastArr;
    }
}

renderList(personArr);

/*  把功能模块化，有利于维护和合作
    var Store = createStore({
        text: '',
        sex: 'a'
    });

    function show() {
        console.log('sub');
    }

    Store.subscribe(show);
    Store.dispatch({type: 'text', value: '刘'});

    function createStore (initState) {
        var state = initState || {};
        var list = [];

        function getState() {
            return State;
        }

        function dispatch(action) {   //改变捕获
            state[action.type] = action.value;
            list.forEach(function (ele, index) {
                ele();
            });
        }

        function subscribe (func) {   //改变捕获后触发渲染
            list.push(func);
        }

        return {
            getState: getState,
            dispatch: dispatch,
            subscribe: subscribe
        }
    }
*/