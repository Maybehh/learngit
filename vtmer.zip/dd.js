var a = document. getElementById("mycontent1");
function change(_id,_name){
    var cont1 = document. getElementById("picture-box1");
    var cont2 = document. getElementById("picture-box2");
    var cont3 = document. getElementById("picture-box3");
    var cont4 = document. getElementById("picture-box4"); 
    var conte1 = document. getElementById("mycontent1");
    var conte2 = document. getElementById("mycontent2");
    var conte3 = document. getElementById("mycontent3");
    var conte4 = document. getElementById("mycontent4");
    if(_name == "picture-box1") 
      { cont1.style.display = "block";
        cont2.style.display = "none"; 
        cont3.style.display = "none";
        cont4.style.display = "none";
        conte1.style.background = "#fff";
        conte1.style.color = "#000";
        }  
    if(_name == "picture-box2") 
      { cont2.style.display = "block";
        cont1.style.display = "none";
        cont3.style.display = "none";
        cont4.style.display = "none";
        conte2.style.background = "#fff";
        conte2.style.color = "#000";
        }  
    if(_name == "picture-box3") 
      {cont3.style.display = "block";
        cont1.style.display = "none";
        cont2.style.display = "none";
        cont4.style.display = "none";
        conte3.style.background = "#fff";
        conte3.style.color = "#000";   
        }  
    if(_name == "picture-box4") 
      { cont4.style.display = "block";
        cont1.style.display = "none";
        cont2.style.display = "none";
        cont3.style.display = "none";
        conte4.style.background = "#fff";
        conte4.style.color = "#000";   
       }
    var conte = document. getElementById("_id"); 
    if(a.id != conte.id){
        a.style.background = "#000";
        a.style.color = "#fff";
       }
    a = document. getElementById("_id");

 }
 